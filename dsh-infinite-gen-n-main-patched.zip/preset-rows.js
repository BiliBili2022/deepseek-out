// Generated file. Source: dsh-web-app presets/standard.patch.yml (standard roster).
// Regenerated with: node D:/deepseek/armor-lab/.diag/build_preset_rows.mjs
// 无限N代 v1.0.0：与 0.2.2 宿主 @deepseek-ai/dsh-web-app/presets/standard.patch.yml 逐行对齐
// （含 subagent modelSelection/modelDiscovery 等新版 config），尾部追加 armor-genn 行。
// 0.2.0-rc.2 时代的子路径行（dsh-tool-subagent-control/list-agents 等）已随版本对齐移除。
// 注意：disabled 的 !!js 表达式是 YAML 方言，JS 版用启动时求值代替。
const IS_WIN = process.platform === "win32";
export const ROWS = [
  {
    "id": "persona",
    "name": "@deepseek-ai/dsh-persona",
    "config": {
      "prefix": "You are a coding agent powered by the {{model}} model."
    }
  },
  {
    "id": "agent-instructions",
    "name": "@deepseek-ai/dsh-agent-instructions",
    "config": {
      "maxBytes": 65536
    }
  },
  {
    "id": "time-context",
    "name": "@deepseek-ai/dsh-time-context"
  },
  {
    "id": "tool-bash",
    "name": "@deepseek-ai/dsh-tool-bash",
    "disabled": IS_WIN
  },
  {
    "id": "tool-pwsh",
    "name": "@deepseek-ai/dsh-tool-pwsh",
    "disabled": !IS_WIN
  },
  {
    "id": "tool-fs",
    "name": "@deepseek-ai/dsh-tool-fs",
    "config": {
      "applyPatch": false
    }
  },
  {
    "id": "tool-fs-search",
    "name": "@deepseek-ai/dsh-tool-fs-search",
    "config": {
      "sampleOverCapGlobResults": false
    }
  },
  {
    "id": "tool-jobs",
    "name": "@deepseek-ai/dsh-tool-jobs"
  },
  {
    "id": "tool-schedule",
    "name": "@deepseek-ai/dsh-tool-schedule"
  },
  {
    "id": "skill-filesystem",
    "name": "@deepseek-ai/dsh-skill-filesystem"
  },
  {
    "id": "tool-skill",
    "name": "@deepseek-ai/dsh-tool-skill"
  },
  {
    "id": "command-goal",
    "name": "@deepseek-ai/dsh-command-goal"
  },
  {
    "id": "tool-goal",
    "name": "@deepseek-ai/dsh-tool-goal"
  },
  {
    "id": "planning",
    "name": "cordis:group",
    "group": true,
    "isolate": {
      "planMode": true
    },
    "config": [
      {
        "id": "plan-mode",
        "name": "@deepseek-ai/dsh-plan-mode",
        "config": {
          "section": "You are in plan mode. Stay in plan mode until the user approves your plan through exit_plan_mode or switches the session mode. Imperative language to implement changes means plan the implementation, not execute it. A user's conversational agreement — including an answer confirming something you asked — approves nothing and does not end plan mode; fold the confirmed decision into the plan and submit it through exit_plan_mode.\nExplore first. Use non-mutating reads, searches, static analysis, and checks to ground the plan in the actual repository. Do not edit or write files, change configuration, run formatters or code generation that rewrites tracked files, commit, or otherwise carry out the plan. Prefer existing functions and patterns over new machinery.\nThe tool catalog stays the same across modes for request-cache stability. These plan-mode rules override any later tool description or guidance that suggests using mutation tools; those tools remain listed to keep the tool catalog unchanged. Do not use todo_write to track this planning phase: it tracks implementation after an approved plan, while the exit_plan_mode belongs to the plan itself.\nResolve discoverable facts by inspection. Use ask_user_question only for user-owned choices or material ambiguity that inspection cannot answer. Do not ask the user where code lives or how it works when you can find out.\nMake the plan decision-complete: state the goal and success criteria; group implementation changes by subsystem; identify public API, schema, data-flow changes; cover edge cases, failure modes, tests, acceptance criteria, and explicit assumptions. Keep it concise enough to review but detailed enough that another engineer could implement it without making design decisions.\nWhen ready, call exit_plan_mode with the complete plan markdown, starting with a # title. Make exit_plan_mode the only and final tool call in that assistant response: it presents the plan for approval, and implementation begins only in a later step after approval. Do not paste the final plan as a plain reply or ask \"should I proceed?\" through prose or ask_user_question. If review rejects it, incorporate the feedback and present again. If the review channel is unavailable or aborted, stay in plan mode and ask the user to switch modes manually; do not proceed with implementation."
        }
      }
    ]
  },
  {
    "id": "compaction",
    "name": "cordis:group",
    "group": true,
    "isolate": {
      "compaction": true,
      "toolResultPruner": true
    },
    "config": [
      {
        "id": "compaction-basic",
        "name": "@deepseek-ai/dsh-compaction-basic"
      },
      {
        "id": "command-compact",
        "name": "@deepseek-ai/dsh-command-compact"
      },
      {
        "id": "tool-result-pruner",
        "name": "@deepseek-ai/dsh-compaction-tool-result-pruner",
        "config": {
          "thresholdChars": 8192,
          "headChars": 4096,
          "tailChars": 1024
        }
      }
    ]
  },
  {
    "id": "delegation",
    "name": "cordis:group",
    "group": true,
    "isolate": {
      "workflowEngine": true
    },
    "config": [
      {
        "id": "tool-subagent-control",
        "name": "@deepseek-ai/dsh-tool-subagent-control",
        "config": {
          "interrupt": false
        }
      },
      {
        "id": "tool-subagent",
        "name": "@deepseek-ai/dsh-tool-subagent",
        "config": {
          "provider": "spawn",
          "toolName": "subagent",
          "modelSelection": true,
          "modelDiscovery": true
        }
      },
      {
        "id": "tool-subagent-fork",
        "name": "@deepseek-ai/dsh-tool-subagent",
        "config": {
          "provider": "fork",
          "toolName": "subagent_fork"
        }
      },
      {
        "id": "workflow-ptc",
        "name": "@deepseek-ai/dsh-workflow-ptc",
        "config": {
          "provider": "spawn"
        }
      },
      {
        "id": "tool-workflow",
        "name": "@deepseek-ai/dsh-tool-workflow"
      }
    ]
  },
  {
    "id": "tool-ask-user",
    "name": "@deepseek-ai/dsh-tool-ask-user"
  },
  {
    "id": "tool-todo",
    "name": "@deepseek-ai/dsh-tool-todo",
    "config": {
      "allowParallelInProgress": true
    }
  },
  {
    "id": "tool-web",
    "name": "@deepseek-ai/dsh-tool-web",
    "config": {
      "fetch": true,
      "searchTimeoutMs": 60000
    }
  },
  {
    "id": "present",
    "name": "@deepseek-ai/dsh-tool-present"
  },
  {
    "id": "tool-office",
    "name": "@deepseek-ai/dsh-tool-office"
  },
  {
    "id": "tool-plugin-manager",
    "name": "@deepseek-ai/dsh-plugin-manager/tools",
    "disabled": true
  },
  {
    "id": "tool-plugin-market",
    "name": "@deepseek-ai/dsh-plugin-market/tools",
    "disabled": true
  },
  {
    "id": "armor-genn",
    "name": "dsh-infinite-gen-n",
    "config": {
      "mode": "armor",
      "via": "preset"
    }
  }
];
